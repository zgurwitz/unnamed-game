module Main where

import UI (run)

main :: IO ()
main = run
