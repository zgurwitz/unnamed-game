import qualified Tests 

main :: IO ()
main = Tests.main
