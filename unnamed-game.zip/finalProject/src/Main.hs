module Main where
import UI (run)

main = do
  run


